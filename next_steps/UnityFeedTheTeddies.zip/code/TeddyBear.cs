﻿using UnityEngine;
using System.Collections;

public class TeddyBear : MonoBehaviour {

	// shooting support
	float elapsedShotTime = 0;
	float firingDelay;
	
	// sound effects support
	AudioSource bounceSound;
	AudioSource shootSound;

	// Use this for initialization
	void Start () {
	
		firingDelay = GetRandomFiringDelay();
		
		// save audio sources
		AudioSource[] audioSources = gameObject.GetComponents<AudioSource>();
		foreach( AudioSource audioSource in audioSources ) {
		
			if ( audioSource.clip.name == "TeddyBounce" ) {

				bounceSound = audioSource;

			} else if ( audioSource.clip.name == "TeddyShot" ) {

				shootSound = audioSource;
			}
		}
	}
	
	// Update is called once per frame
	void Update () {
	
		// fire projectile as appropriate
		// timer concept (for animations) introduced in Chapter 7

			// in if body: reset elapsed shot time and get new random firing delay

			// in if body: create and place projectile
			
			// in if body: shoot projectile down

			// in if body: play sound effect

	}

	// Called on a collision
	void OnCollisionEnter2D( Collision2D coll ) {

		// play bounce sound effect, but only for collisions
		// with the main camera or another teddy bear


	}

	/// <summary>
	/// Gets the location of the teddy bear
	/// </summary>
	public Vector2 Location
	{
		get { return transform.position; }
	}

	/// <summary>
	/// Gets a random firing delay between MIN_FIRING_DELAY and
	/// MIN_FIRING_DELY + FIRING_RATE_RANGE
	/// </summary>
	/// <returns>the random firing delay</returns>
	private float GetRandomFiringDelay()
	{
		return Random.Range (GameConstants.BEAR_MIN_FIRING_DELAY, 
		                     GameConstants.BEAR_MIN_FIRING_DELAY + GameConstants.BEAR_FIRING_RATE_RANGE);
	}
}
