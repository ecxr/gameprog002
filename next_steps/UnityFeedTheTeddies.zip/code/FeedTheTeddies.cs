﻿using UnityEngine;
using System.Collections;

public class FeedTheTeddies : MonoBehaviour {

	// teddy bear
	public GameObject prefabTeddyBear;

	// score support
	float score = 0;
	GUIText scoreText = null;

	// cached for efficiency
	float teddyBearColliderHalfWidth;
	float teddyBearColliderHalfHeight;

	// spawn support, cached for efficiency
	int minSpawnX;
	int maxSpawnX;
	int minSpawnY;
	int maxSpawnY;

	// Use this for initialization
	void Start () {
	
		// save score text and set initial text
//		scoreText = GameObject.Find("score").GetComponent<GUIText>();
//		scoreText.text = GameConstants.SCORE_PREFIX + score;

		// save spawn boundaries for efficiency
		minSpawnX = GameConstants.SPAWN_BORDER_SIZE;
		maxSpawnX = Screen.width - GameConstants.SPAWN_BORDER_SIZE;
		minSpawnY = GameConstants.SPAWN_BORDER_SIZE;
		maxSpawnY = Screen.height - GameConstants.SPAWN_BORDER_SIZE;

		// spawn and destroy a bear to cache collider values
//		GameObject tempBear = Instantiate( prefabTeddyBear ) as GameObject;
//		BoxCollider2D collider = tempBear.GetComponent<BoxCollider2D>();
//		Vector3 diff = collider.bounds.max - collider.bounds.min;
//		teddyBearColliderHalfWidth = diff.x / 2;
//		teddyBearColliderHalfHeight = diff.y / 2;
//		Destroy ( tempBear );

		// spawn bears

	}
	
	// Update is called once per frame
	void Update () {
	
		// spawn new bears as necessary

	}

	// Spawns a new teddy bear at a random location
	private void SpawnBear()
	{
		// generate random location (Increment 1) and calculate teddy bear collision rectangle (Increment 4)

		// make sure we don't spawn into a collision

			// in loop body: change location and calculate new rectangle points

		// create new bear

		// generate random initial force and move new bear

	}
	
	/// <summary>
	/// Gets a random location using the given min and range
	/// </summary>
	/// <param name="min">the minimum</param>
	/// <param name="range">the range</param>
	/// <returns>the random location</returns>
	private int GetRandomLocation(int min, int range)
	{
		return Random.Range (min, min + range);
	}

}
