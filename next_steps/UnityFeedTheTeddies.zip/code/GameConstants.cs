﻿using UnityEngine;
using System.Collections;

public static class GameConstants {

	// projectile characteristics
	public const float TEDDY_BEAR_PROJECTILE_INITIAL_FORCE = 8f;
	public const int TEDDY_BEAR_PROJECTILE_DAMAGE = 5;
	public const float TEDDY_BEAR_PROJECTILE_OFFSET = 0.2f;
	public const float FRENCH_FRIES_PROJECTILE_INITIAL_FORCE = 10f;
	public const int FRENCH_FRIES_PROJECTILE_DAMAGE = 5;
	public const float FRENCH_FRIES_PROJECTILE_OFFSET = 0.1f;
	
	// bear characteristics
	public const int MAX_BEARS = 5;
	public const int BEAR_POINTS = 10;
	public const int BEAR_DAMAGE = 10;
	public const float BEAR_MAX_INITIAL_FORCE = 5f;
	public const float BEAR_MIN_FIRING_DELAY = 0.5f;
	public const float BEAR_FIRING_RATE_RANGE = 1f;
	
	// burger characteristics
	public const float BURGER_MOVEMENT_AMOUNT = 0.1f;
	public const float BURGER_COOLDOWN_SECONDS = 0.5f;
	
	// text display support
	public const string SCORE_PREFIX = "Score: ";
	public const string HEALTH_PREFIX = "Health: ";
	
	// spawn location support
	public const int SPAWN_BORDER_SIZE = 100;
}
