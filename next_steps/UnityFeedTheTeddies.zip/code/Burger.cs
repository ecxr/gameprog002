﻿using UnityEngine;
using System.Collections;

public class Burger : MonoBehaviour {

	// burger stats and status
	int health = 100;
	bool burgerDead = false;
	GUIText healthText = null;

	// shooting support
	bool canShoot = true;
	float elapsedCooldownTime = 0;

	// used for clamping
	Rect cameraRect;
	float halfWidth;
	float halfHeight;

	// sound effects support
	AudioSource damageSound;
	AudioSource deathSound;
	AudioSource shootSound;

	// Use this for initialization
	void Start () {

		// calculate camera rectangle for clamping on screen
		Vector3 bottomLeft = Camera.main.ScreenToWorldPoint(new Vector3(
			0, 0, -Camera.main.transform.position.z));
		Vector3 topRight = Camera.main.ScreenToWorldPoint(new Vector3(
			Screen.width, Screen.height, -Camera.main.transform.position.z));
		cameraRect = new Rect(
			bottomLeft.x,
			bottomLeft.y,
			topRight.x - bottomLeft.x,
			topRight.y - bottomLeft.y);

		// save half width and half height for efficiency
		BoxCollider2D collider = GetComponent<BoxCollider2D>();
		halfWidth = collider.size.x / 2;
		halfHeight = collider.size.y / 2;

		// save audio sources
		AudioSource[] audioSources = gameObject.GetComponents<AudioSource>();
		foreach( AudioSource audioSource in audioSources ) {
			
			if ( audioSource.clip.name == "BurgerDamage" ) {
				
				damageSound = audioSource;

			} else if ( audioSource.clip.name == "BurgerDeath" ) {
				
				deathSound = audioSource;
			
			} else if ( audioSource.clip.name == "BurgerShot" ) {
				
				shootSound = audioSource;
			}
		}

		// save health text and set initial text
//		healthText = GameObject.Find("health").GetComponent<GUIText>();
//		healthText.text = GameConstants.HEALTH_PREFIX + health;
	}
	
	// Update is called once per frame
	void Update () {
	
		// burger should only respond to input if it still has health
		if ( health > 0 ) {

			// move burger using mouse

			// clamp burger in window
//			Vector3 pos = Vector3.zero;
//			pos.x = Mathf.Clamp(transform.position.x, cameraRect.xMin + halfWidth, cameraRect.xMax - halfWidth);
//			pos.y = Mathf.Clamp(transform.position.y, cameraRect.yMin + halfHeight, cameraRect.yMax - halfHeight);
//			transform.position = pos;

			// update shooting allowed
			// timer concept (for animations) introduced in Chapter 7

				// in if body: update elapsed cooldwon time and set canShoot if appropriate

					// in nested if body: re-enable shooting and reset cooldown timer
		
			// shoot if appropriate

				// in if body: create and place projectile

				// in if body: shoot projectile up

				// in if body: play sound effect

		}
	}

	// Called on a collision enter
	void OnCollisionEnter2D( Collision2D coll ) {

		// check for collision with a teddy bear

	}
}
