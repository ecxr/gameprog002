﻿using UnityEngine;
using System.Collections;

public class Projectile : MonoBehaviour {

	// Called on a 2D physics collision (because the projectile colliders are marked as triggers) 
	void OnTriggerEnter2D( Collider2D other) {
		
		// if the collision is between french fries and a teddy bear, destroy both game objects

			// in if body: create explosion at teddy bear and destroy both objects

		// else if the collision is between a teddy bear projectile and the burger

			// in else if body: create explosion at projectile, destroy projectile, and reduce burger health
	}

	// Called when the projectile becomes invisible
	void OnBecameInvisible() {

		// destroy the game object

	}
}